==========
ContactVis
==========

Python package for simple protein residue-residue contact map plotting.
